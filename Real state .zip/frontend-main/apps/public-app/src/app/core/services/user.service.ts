import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { API_CONSTANTS } from '../constants/api.constants';
import { User } from '../models/user.model';
import { StorageUtils } from '../../features/auth/utils/storage.utils';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    constructor(private http: HttpClient) { }

    async getUserByWallet(wallet: string): Promise<User> {
        try {
            const token = StorageUtils.getAccessToken();
            const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

            // Try to fetch from backend
            return await lastValueFrom(this.http.get<User>(
                `${API_CONSTANTS.GATEWAY_URL}${API_CONSTANTS.ENDPOINTS.USERS.BY_WALLET(wallet)}`,
                { headers }
            ));
        } catch (error) {
            console.warn('Failed to fetch user from backend, returning mock data for development.', error);
            // Return mock data if backend fails (for development)
            return {
                id: '1',
                username: 'crypto_enthusiast',
                firstName: 'Alex',
                lastName: 'Mercer',
                email: 'alex.mercer@example.com',
                description: 'Early adopter of Web3 technologies. Looking for a modern apartment in the city center.',
                wallet: wallet,
                role: 'ROLE_USER'
            };
        }
    }

    async getUserById(userId: number): Promise<User> {
        try {
            const token = StorageUtils.getAccessToken();
            const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

            return await lastValueFrom(this.http.get<User>(
                `${API_CONSTANTS.GATEWAY_URL}${API_CONSTANTS.ENDPOINTS.USERS.BASE}/id/${userId}`,
                { headers }
            ));
        } catch (error) {
            console.error('Failed to fetch user by ID:', error);
            throw error;
        }
    }

    async updateUser(user: User): Promise<User> {
        const token = StorageUtils.getAccessToken();
        const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

        // Assuming the endpoint is PUT /users/{id} or /users/profile
        // Based on getUserByWallet, let's assume we can update by ID if available, or we might need a specific endpoint.
        // Since we don't have the exact endpoint for update in the context, I'll assume a standard RESTful update by ID.
        // However, the user entity has an ID.

        if (!user.id) {
            throw new Error('User ID is required for update');
        }

        return await lastValueFrom(this.http.patch<User>(
            `${API_CONSTANTS.GATEWAY_URL}${API_CONSTANTS.ENDPOINTS.USERS.BASE}/${user.id}`,
            user,
            { headers }
        ));
    }
}
